"""Vehicle & person registry + numbered SQLite schema migrations + re-entrant inter-process lock helper.
Faces are NOT imported: a person's face can only be enrolled live from the camera, and only if
the person's record says they consented.
Round 4 upgrades:
- P0-A: Strict person identity isolation via internal person_id (persons.id) across enrollment, consent revocation,
  status updates, deletion, and known-face loading, plus safe migration/quarantine of legacy ambiguous faces.
- P1-D: Removal of static fallback HMAC key, atomic secret/key file writing with 0600 permissions from creation,
  and explicit refusal to silently overwrite corrupt/truncated HMAC keys."""
import contextlib, csv, hashlib, hmac, io, os, re, secrets, shutil, sqlite3, stat, threading, time

try:
    import fcntl
except ImportError:
    fcntl = None
try:
    import msvcrt
except ImportError:
    msvcrt = None

VSTAT = {"normal": "عادية", "watch": "مراقبة", "wanted": "مطلوبة", "stolen": "مسروقة", "expired": "منتهية الترخيص"}
KW_V = {"watch": ["مراقب", "watch"], "wanted": ["مطلوب", "wanted"], "stolen": ["مسروق", "stolen"],
        "expired": ["منتهي", "expired"], "normal": ["عادي", "normal"]}
KW_P = {"watch": ["مراقب", "watch"], "normal": ["عادي", "normal"]}
KW_T = {"truck": ["شاحن", "truck", "لوري"], "bus": ["حاف", "bus", "باص"],
        "motorcycle": ["دراج", "motor"], "car": ["سيار", "car"]}
D = {}                                               # db, lock, log, refresh, db_path (set by init)
DIG = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
AR_NORM = str.maketrans({"أ": "ا", "إ": "ا", "آ": "ا", "ة": "ه", "ى": "ي", "ـ": ""})
OCR_DIGIT_CONFUSIONS = str.maketrans({"O": "0", "o": "0", "I": "1", "l": "1", "|": "1", "S": "5", "s": "5", "B": "8", "Z": "2"})
hkey = lambda h: re.sub(r"[\s()_\-:/]", "", str(h or "")).lower()
_HMAC_KEY_CACHE = {}
_IPC_RLOCK = threading.RLock()
_IPC_STATE = {"depth": 0, "fd": None}


def atomic_write_secret_bytes(target_path, data_bytes):
    """Atomically write secret bytes with restricted owner-only permissions (0600) from creation (P1-D).
    - Creates a protected temp file via os.open(..., O_CREAT|O_EXCL|O_WRONLY, 0o600).
    - Writes all bytes, flushes, fsyncs, verifies length & permissions, then atomically replaces target_path.
    - Cleans up temp file on any error or interruption so partial/unprotected files are never left behind."""
    if not isinstance(data_bytes, (bytes, bytearray)):
        data_bytes = str(data_bytes).encode("utf-8")
    parent_dir = os.path.dirname(os.path.abspath(target_path))
    if not parent_dir or not os.path.isdir(parent_dir):
        raise OSError(f"Target directory does not exist: {parent_dir}")
    if os.path.lexists(target_path) and os.path.islink(target_path):
        raise OSError(f"Refusing to write secret to symlink path: {target_path}")

    tmp_path = os.path.join(parent_dir, f".{os.path.basename(target_path)}.tmp.{os.getpid()}.{secrets.token_hex(6)}")
    fd = None
    try:
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0)
        fd = os.open(tmp_path, flags, 0o600)
        try:
            os.chmod(tmp_path, 0o600)
        except OSError:
            pass
        total_written = 0
        mv = memoryview(data_bytes)
        while total_written < len(data_bytes):
            n_w = os.write(fd, mv[total_written:])
            if n_w <= 0:
                raise OSError("Short write while saving secret file")
            total_written += n_w
        os.fsync(fd)
        os.close(fd)
        fd = None

        st_info = os.stat(tmp_path)
        if st_info.st_size != len(data_bytes):
            raise OSError(f"Incomplete secret write ({st_info.st_size} != {len(data_bytes)})")
        if os.name == "posix" and (stat.S_IMODE(st_info.st_mode) & 0o077) != 0:
            os.chmod(tmp_path, 0o600)
            st_info = os.stat(tmp_path)
            if (stat.S_IMODE(st_info.st_mode) & 0o077) != 0:
                raise OSError(f"Failed to enforce 0600 permissions on {tmp_path}")

        os.replace(tmp_path, target_path)
    finally:
        if fd is not None:
            try: os.close(fd)
            except OSError: pass
        if os.path.lexists(tmp_path):
            try: os.remove(tmp_path)
            except OSError: pass


def _get_hmac_key():
    """Load or create a local 32-byte secret key for HMAC pseudonymization (P1-D).
    - Never falls back to a static hardcoded key: raises RuntimeError if key storage is unavailable or unwritable.
    - Never silently overwrites a corrupt or truncated key file (which would alter existing pseudonyms)."""
    base_dir = os.environ.get("MERSAD_DATA_DIR") or os.getcwd()
    key_path = os.path.abspath(os.path.join(base_dir, ".mersad_hmac.key"))
    if os.path.lexists(key_path):
        if os.path.islink(key_path):
            _HMAC_KEY_CACHE.pop(key_path, None)
            raise RuntimeError(f"Security error: HMAC key file {key_path} cannot be a symbolic link")
        try:
            with open(key_path, "rb") as f:
                k = f.read()
        except OSError as e:
            _HMAC_KEY_CACHE.pop(key_path, None)
            raise RuntimeError(f"Cannot read HMAC key file {key_path}: {e}") from e
        if len(k) < 32:
            _HMAC_KEY_CACHE.pop(key_path, None)
            raise RuntimeError(
                f"Corrupt or truncated HMAC key file at {key_path} ({len(k)} bytes < 32). "
                "Refusing to silently generate a replacement key to protect audit pseudonym integrity."
            )
        if os.name == "posix":
            try:
                st_mode = stat.S_IMODE(os.stat(key_path).st_mode)
                if (st_mode & 0o077) != 0:
                    os.chmod(key_path, 0o600)
            except OSError:
                pass
        _HMAC_KEY_CACHE[key_path] = k
        return k

    _HMAC_KEY_CACHE.pop(key_path, None)
    k = secrets.token_bytes(32)
    try:
        atomic_write_secret_bytes(key_path, k)
    except OSError as e:
        raise RuntimeError(f"Cannot securely create or persist HMAC key at {key_path}: {e}") from e
    _HMAC_KEY_CACHE[key_path] = k
    return k


def pseud(s):
    """Keyed HMAC-SHA256 pseudonym so person names/plates in audit logs cannot be brute-forced (P2-K, P1-D)."""
    key = _get_hmac_key()
    digest = hmac.new(key, str(s or "").encode("utf-8", "ignore"), hashlib.sha256).hexdigest()[:12]
    return "p-" + digest


@contextlib.contextmanager
def interprocess_db_lock(db_path=None):
    """Re-entrant thread + OS-level inter-process file lock for atomic multi-process SQLite writes (P0-E)."""
    t_lock = D.get("lock")
    p = db_path or D.get("db_path") or os.path.join(os.environ.get("MERSAD_DATA_DIR") or os.getcwd(), "mersad.db")
    lock_file = f"{p}.ipclock"
    _IPC_RLOCK.acquire()
    if t_lock is not None:
        t_lock.acquire()
    try:
        if _IPC_STATE["depth"] == 0 and p and p != ":memory:":
            fd = open(lock_file, "a+b")
            if fcntl is not None:
                fcntl.flock(fd.fileno(), fcntl.LOCK_EX)
            elif msvcrt is not None:
                fd.seek(0)
                msvcrt.locking(fd.fileno(), msvcrt.LK_LOCK, 1)
            _IPC_STATE["fd"] = fd
        _IPC_STATE["depth"] += 1
        yield
    finally:
        _IPC_STATE["depth"] -= 1
        if _IPC_STATE["depth"] == 0 and _IPC_STATE["fd"] is not None:
            fd = _IPC_STATE["fd"]
            _IPC_STATE["fd"] = None
            try:
                if fcntl is not None:
                    fcntl.flock(fd.fileno(), fcntl.LOCK_UN)
                elif msvcrt is not None:
                    fd.seek(0)
                    msvcrt.locking(fd.fileno(), msvcrt.LK_UNLCK, 1)
            except Exception:
                pass
            try: fd.close()
            except Exception: pass
        if t_lock is not None:
            t_lock.release()
        _IPC_RLOCK.release()


def run_atomic_tx(db, lock, fn, db_path=None, retries=20):
    """Execute fn(db) inside BEGIN IMMEDIATE with re-entrant OS file lock and bounded retry on SQLite lock contention (P0-E)."""
    last_err = None
    for attempt in range(retries):
        try:
            with interprocess_db_lock(db_path):
                started_tx = False
                if not db.in_transaction:
                    db.execute("BEGIN IMMEDIATE")
                    started_tx = True
                try:
                    res = fn(db)
                    if started_tx:
                        db.commit()
                    return res
                except Exception:
                    if started_tx and db.in_transaction:
                        try: db.rollback()
                        except Exception: pass
                    raise
        except sqlite3.OperationalError as oe:
            last_err = oe
            if "locked" in str(oe).lower() or "busy" in str(oe).lower():
                time.sleep(0.01 * (attempt + 1))
                continue
            raise
    raise last_err


def _alias(m): return {hkey(a): k for k, v in m.items() for a in v}


AV = _alias({"plate": ["رقم اللوحة", "اللوحة", "رقم", "plate", "plate number", "number"],
             "governorate": ["المحافظة", "المدينة", "governorate", "city"],
             "model": ["اسم السيارة (الطراز)", "اسم السيارة", "السيارة", "الطراز", "model", "make", "vehicle"],
             "color": ["اللون", "color"], "vtype": ["النوع", "نوع المركبة", "type", "vehicle type"],
             "owner": ["اسم المالك", "المالك", "owner"], "status": ["الحالة", "status"],
             "notes": ["ملاحظات", "notes", "note"]})
AP = _alias({"name": ["الاسم", "اسم الشخص", "name", "full name"],
             "ref": ["الرقم المرجعي", "رقم مرجعي", "ref", "id", "reference"],
             "category": ["الفئة", "التصنيف", "category", "role"], "status": ["الحالة", "status"],
             "consent": ["موافقة (نعم/لا)", "موافقة", "consent"], "notes": ["ملاحظات", "notes", "note"]})
VH = ["رقم اللوحة", "المحافظة", "اسم السيارة (الطراز)", "اللون", "النوع", "اسم المالك", "الحالة", "ملاحظات"]
PH = ["الاسم", "الرقم المرجعي", "الفئة", "الحالة", "موافقة (نعم/لا)", "ملاحظات"]
VEX = ["00000", "عدن", "تويوتا هايلكس", "أبيض", "شاحنة", "مثال فقط", "عادية", ""]
PEX = ["مثال (احذف هذا السطر)", "V-001", "متطوع", "عادي", "نعم", ""]


def _fix_ocr_numeric_tokens(raw_str):
    """Normalize OCR lookalike characters (O->0, I/l->1, S->5, B->8, Z->2) ONLY inside tokens that contain digits."""
    tokens = re.split(r"([\s\-_/]+)", raw_str)
    out = []
    fixed = False
    for tok in tokens:
        if any(ch.isdigit() for ch in tok) and any(ch in "OoIl|SsBZ" for ch in tok):
            new_tok = tok.translate(OCR_DIGIT_CONFUSIONS)
            if new_tok != tok:
                fixed = True
            out.append(new_tok)
        else:
            out.append(tok)
    return "".join(out), fixed


def split_plate_ex(s):
    """Extract (core_digits, normalized_letters, ocr_confusion_fixed) from any plate string."""
    raw = str(s or "").translate(DIG).translate(AR_NORM).strip().upper()
    if not raw:
        return "", "", False
    raw_fixed, ocr_fixed = _fix_ocr_numeric_tokens(raw)
    digits = "".join(re.findall(r"\d", raw_fixed))
    letters = "".join(re.findall(r"[A-Z\u0621-\u064A]", raw_fixed))[:8]
    return digits, letters, ocr_fixed


def split_plate(s):
    """Extract (core_digits, normalized_letters) from any Arabic/Persian/English plate string."""
    digits, letters, _ = split_plate_ex(s)
    return digits, letters


def norm_plate(s, governorate=""):
    """Canonical representation of a plate string: 'letters-digits' when letters or governorate exist, else 'digits'."""
    digits, letters = split_plate(s)
    if not digits:
        return ""
    eff_letters = letters or _norm_letters_only(governorate)
    if eff_letters:
        return f"{eff_letters}-{digits}"
    return digits


def _norm_letters_only(s):
    raw = str(s or "").translate(DIG).translate(AR_NORM).strip().upper()
    return "".join(re.findall(r"[A-Z\u0621-\u064A]", raw))[:8]


def _letter_similarity(a, b):
    """Compute character overlap / subsequence similarity in [0.0, 1.0] between two normalized letter strings."""
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    if a in b or b in a:
        return max(0.55, 0.85 * (min(len(a), len(b)) / max(len(a), len(b))))
    common = sum(1 for ch in set(a) if ch in set(b))
    return common / max(len(set(a)), len(set(b)))


def _edit_distance_1(a, b):
    """Return True if strings a and b have Levenshtein edit distance == 1 (and lengths >= 4)."""
    if not a or not b or min(len(a), len(b)) < 4 or abs(len(a) - len(b)) > 1:
        return False
    if a == b:
        return False
    if len(a) == len(b):
        return sum(1 for x, y in zip(a, b) if x != y) == 1
    shorter, longer = (a, b) if len(a) < len(b) else (b, a)
    i = j = diffs = 0
    while i < len(shorter) and j < len(longer):
        if shorter[i] == longer[j]:
            i += 1; j += 1
        else:
            diffs += 1
            j += 1
            if diffs > 1:
                return False
    return True


def migrate_legacy_faces(db):
    """Safely migrate or quarantine legacy face rows that lack a valid unambiguous person_id (P0-A item 7):
    - Never guesses randomly when multiple persons share the same name: quarantines ambiguous rows (quarantined=1).
    - Never grants automatic consent to faces whose person has consent=0: quarantines them.
    - Assigns person_id ONLY when exactly 1 person record exists with that name AND has active consent=1."""
    cols_f = {r[1] for r in db.execute("PRAGMA table_info(faces)").fetchall()}
    if "quarantined" not in cols_f:
        try: db.execute("ALTER TABLE faces ADD COLUMN quarantined INTEGER DEFAULT 0")
        except sqlite3.OperationalError: pass
    if "quarantine_reason" not in cols_f:
        try: db.execute("ALTER TABLE faces ADD COLUMN quarantine_reason TEXT DEFAULT ''")
        except sqlite3.OperationalError: pass
    if "person_id" not in cols_f:
        try: db.execute("ALTER TABLE faces ADD COLUMN person_id INTEGER DEFAULT 0")
        except sqlite3.OperationalError: pass

    unassigned = db.execute(
        "SELECT rowid, COALESCE(name,''), COALESCE(person_id,0) FROM faces "
        "WHERE COALESCE(quarantined, 0) = 0 AND ("
        "  COALESCE(person_id, 0) <= 0 "
        "  OR NOT EXISTS (SELECT 1 FROM persons p WHERE p.id = faces.person_id)"
        ")"
    ).fetchall()
    if not unassigned:
        return 0

    quarantined_cnt = 0
    for f_rowid, f_name, f_pid in unassigned:
        if f_pid > 0:
            # Had a person_id that no longer exists in persons -> quarantine orphan
            db.execute(
                "UPDATE faces SET person_id=0, quarantined=1, quarantine_reason='orphan_person_id_not_found' WHERE rowid=?",
                (f_rowid,)
            )
            quarantined_cnt += 1
            continue
        p_rows = db.execute(
            "SELECT id, COALESCE(consent,0), COALESCE(status,'normal') FROM persons WHERE name=?",
            (f_name,)
        ).fetchall()
        if len(p_rows) == 1 and int(p_rows[0][1]) == 1:
            pid, _, p_st = p_rows[0]
            db.execute(
                "UPDATE faces SET person_id=?, watch=?, quarantined=0, quarantine_reason='' WHERE rowid=?",
                (pid, int(p_st == "watch"), f_rowid)
            )
        elif len(p_rows) > 1:
            db.execute(
                "UPDATE faces SET person_id=0, quarantined=1, quarantine_reason='ambiguous_legacy_name_multiple_persons' WHERE rowid=?",
                (f_rowid,)
            )
            quarantined_cnt += 1
        elif len(p_rows) == 1 and int(p_rows[0][1]) == 0:
            db.execute(
                "UPDATE faces SET person_id=?, quarantined=1, quarantine_reason='legacy_face_without_consent' WHERE rowid=?",
                (p_rows[0][0], f_rowid)
            )
            quarantined_cnt += 1
        else:
            db.execute(
                "UPDATE faces SET person_id=0, quarantined=1, quarantine_reason='orphan_legacy_face_no_person' WHERE rowid=?",
                (f_rowid,)
            )
            quarantined_cnt += 1
    return quarantined_cnt


def migrate_db(db, lock, db_path=None):
    """Apply numbered, non-destructive schema migrations (v1..v6) with automatic backup of existing database files."""
    with interprocess_db_lock(db_path):
        was_in_tx = db.in_transaction
        if not was_in_tx:
            db.execute("PRAGMA journal_mode=WAL")
            db.execute("PRAGMA busy_timeout=15000")
        db.execute("CREATE TABLE IF NOT EXISTS schema_migrations(version INTEGER PRIMARY KEY, applied_ts REAL, description TEXT)")
        cur_ver = db.execute("SELECT COALESCE(MAX(version), 0) FROM schema_migrations").fetchone()[0]
        if cur_ver >= 6:
            return
        has_legacy = bool(db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='sightings'").fetchone())
        if has_legacy and cur_ver < 6 and db_path and os.path.exists(db_path) and os.path.getsize(db_path) > 0:
            bak = f"{db_path}.bak.v{cur_ver}"
            if not os.path.exists(bak):
                try: shutil.copy2(db_path, bak)
                except OSError: pass

        if cur_ver < 1:
            db.executescript("""
            CREATE TABLE IF NOT EXISTS vehicles(plate TEXT PRIMARY KEY, governorate TEXT, model TEXT, color TEXT,
              vtype TEXT DEFAULT 'car', owner TEXT, status TEXT DEFAULT 'normal', notes TEXT, updated REAL,
              plate_digits TEXT DEFAULT '', plate_letters TEXT DEFAULT '');
            CREATE TABLE IF NOT EXISTS persons(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, ref TEXT DEFAULT '',
              category TEXT, status TEXT DEFAULT 'normal', consent INTEGER DEFAULT 0, notes TEXT, updated REAL, UNIQUE(name, ref));
            CREATE TABLE IF NOT EXISTS faces(name TEXT, emb BLOB, watch INTEGER DEFAULT 0, person_id INTEGER DEFAULT 0,
              quarantined INTEGER DEFAULT 0, quarantine_reason TEXT DEFAULT '');
            CREATE TABLE IF NOT EXISTS sightings(ts REAL, cam TEXT, plate TEXT, conf REAL, vclass TEXT,
              src TEXT DEFAULT 'live', direction TEXT DEFAULT '', raw_text TEXT DEFAULT '', session_id TEXT DEFAULT '');
            CREATE TABLE IF NOT EXISTS audit(i INTEGER PRIMARY KEY, ts REAL, action TEXT, ref TEXT, prev TEXT, hash TEXT);
            """)
            db.execute("INSERT INTO schema_migrations VALUES(1, ?, 'Base tables')", (time.time(),))

        if cur_ver < 2:
            cols_s = {r[1] for r in db.execute("PRAGMA table_info(sightings)").fetchall()}
            for col, ddl in (
                ("vclass", "ALTER TABLE sightings ADD COLUMN vclass TEXT"),
                ("src", "ALTER TABLE sightings ADD COLUMN src TEXT DEFAULT 'live'"),
                ("direction", "ALTER TABLE sightings ADD COLUMN direction TEXT DEFAULT ''"),
                ("raw_text", "ALTER TABLE sightings ADD COLUMN raw_text TEXT DEFAULT ''"),
            ):
                if col not in cols_s:
                    try: db.execute(ddl)
                    except sqlite3.OperationalError: pass
            cols_f = {r[1] for r in db.execute("PRAGMA table_info(faces)").fetchall()}
            if "watch" not in cols_f:
                try: db.execute("ALTER TABLE faces ADD COLUMN watch INTEGER DEFAULT 0")
                except sqlite3.OperationalError: pass
            db.execute("UPDATE sightings SET src='live' WHERE src IS NULL OR src=''")
            db.execute("INSERT INTO schema_migrations VALUES(2, ?, 'Upgrade sightings & faces columns')", (time.time(),))

        if cur_ver < 3:
            db.executescript("""
            CREATE TABLE IF NOT EXISTS alerts(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              ts REAL,
              ts_str TEXT,
              msg TEXT,
              subject TEXT,
              ref TEXT,
              detail TEXT,
              cam TEXT,
              img TEXT,
              status TEXT DEFAULT 'pending',
              decided_by TEXT DEFAULT '',
              decided_ts REAL DEFAULT 0,
              dispatched INTEGER DEFAULT 0,
              dispatch_status TEXT DEFAULT 'not_required',
              dispatch_attempts INTEGER DEFAULT 0,
              next_retry_ts REAL DEFAULT 0,
              last_error TEXT DEFAULT '',
              dispatch_started_ts REAL DEFAULT 0,
              dispatch_owner TEXT DEFAULT '',
              repeat_count INTEGER DEFAULT 1,
              last_seen_ts REAL DEFAULT 0,
              notify_status TEXT DEFAULT 'pending',
              notify_attempts INTEGER DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS camera_links(
              from_cam TEXT,
              to_cam TEXT,
              min_sec REAL DEFAULT 90,
              expected_sec REAL DEFAULT 300,
              source TEXT DEFAULT 'user_calibrated',
              PRIMARY KEY(from_cam, to_cam)
            );
            CREATE INDEX IF NOT EXISTS idx_sightings_plate_ts ON sightings(plate, ts);
            CREATE INDEX IF NOT EXISTS idx_sightings_ts ON sightings(ts);
            CREATE INDEX IF NOT EXISTS idx_alerts_status ON alerts(status);
            CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit(ts);
            """)
            db.execute("INSERT INTO schema_migrations VALUES(3, ?, 'Add alerts, camera_links, and indexes')", (time.time(),))

        if cur_ver < 4:
            cols_v = {r[1] for r in db.execute("PRAGMA table_info(vehicles)").fetchall()}
            for col, ddl in (
                ("plate_digits", "ALTER TABLE vehicles ADD COLUMN plate_digits TEXT DEFAULT ''"),
                ("plate_letters", "ALTER TABLE vehicles ADD COLUMN plate_letters TEXT DEFAULT ''"),
            ):
                if col not in cols_v:
                    try: db.execute(ddl)
                    except sqlite3.OperationalError: pass
            db.execute("CREATE INDEX IF NOT EXISTS idx_vehicles_digits ON vehicles(plate_digits)")

            cols_a = {r[1] for r in db.execute("PRAGMA table_info(alerts)").fetchall()}
            for col, ddl in (
                ("dispatch_status", "ALTER TABLE alerts ADD COLUMN dispatch_status TEXT DEFAULT 'not_required'"),
                ("dispatch_attempts", "ALTER TABLE alerts ADD COLUMN dispatch_attempts INTEGER DEFAULT 0"),
                ("next_retry_ts", "ALTER TABLE alerts ADD COLUMN next_retry_ts REAL DEFAULT 0"),
                ("last_error", "ALTER TABLE alerts ADD COLUMN last_error TEXT DEFAULT ''"),
            ):
                if col not in cols_a:
                    try: db.execute(ddl)
                    except sqlite3.OperationalError: pass
            cols_s = {r[1] for r in db.execute("PRAGMA table_info(sightings)").fetchall()}
            if "session_id" not in cols_s:
                try: db.execute("ALTER TABLE sightings ADD COLUMN session_id TEXT DEFAULT ''")
                except sqlite3.OperationalError: pass
            db.execute("INSERT INTO schema_migrations VALUES(4, ?, 'Add plate_digits/letters, alert dispatch_status, and session_id')", (time.time(),))

        if cur_ver < 5:
            cols_a = {r[1] for r in db.execute("PRAGMA table_info(alerts)").fetchall()}
            for col, ddl in (
                ("dispatch_started_ts", "ALTER TABLE alerts ADD COLUMN dispatch_started_ts REAL DEFAULT 0"),
                ("repeat_count", "ALTER TABLE alerts ADD COLUMN repeat_count INTEGER DEFAULT 1"),
                ("last_seen_ts", "ALTER TABLE alerts ADD COLUMN last_seen_ts REAL DEFAULT 0"),
                ("notify_status", "ALTER TABLE alerts ADD COLUMN notify_status TEXT DEFAULT 'pending'"),
                ("notify_attempts", "ALTER TABLE alerts ADD COLUMN notify_attempts INTEGER DEFAULT 0"),
            ):
                if col not in cols_a:
                    try: db.execute(ddl)
                    except sqlite3.OperationalError: pass

            cols_p = {r[1] for r in db.execute("PRAGMA table_info(persons)").fetchall()}
            if "id" not in cols_p:
                db.executescript("""
                CREATE TABLE IF NOT EXISTS persons_v5(
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  name TEXT,
                  ref TEXT DEFAULT '',
                  category TEXT,
                  status TEXT DEFAULT 'normal',
                  consent INTEGER DEFAULT 0,
                  notes TEXT,
                  updated REAL,
                  UNIQUE(name, ref)
                );
                INSERT OR IGNORE INTO persons_v5(name, ref, category, status, consent, notes, updated)
                  SELECT name, COALESCE(ref,''), category, status, consent, notes, updated FROM persons;
                DROP TABLE persons;
                ALTER TABLE persons_v5 RENAME TO persons;
                """)
            cols_f = {r[1] for r in db.execute("PRAGMA table_info(faces)").fetchall()}
            if "person_id" not in cols_f:
                try: db.execute("ALTER TABLE faces ADD COLUMN person_id INTEGER DEFAULT 0")
                except sqlite3.OperationalError: pass

            v_rows = db.execute("SELECT plate, COALESCE(governorate,'') FROM vehicles").fetchall()
            for pl, gov in v_rows:
                dg, lt_str = split_plate(pl)
                eff_lt = lt_str or _norm_letters_only(gov)
                canon_pl = f"{eff_lt}-{dg}" if (eff_lt and dg) else pl
                if canon_pl != pl:
                    exists_canon = db.execute("SELECT 1 FROM vehicles WHERE plate=?", (canon_pl,)).fetchone()
                    if not exists_canon:
                        db.execute("UPDATE vehicles SET plate=?, plate_digits=?, plate_letters=? WHERE plate=?",
                                   (canon_pl, dg, eff_lt, pl))
                    else:
                        db.execute("UPDATE vehicles SET plate_digits=?, plate_letters=? WHERE plate=?",
                                   (dg, eff_lt, pl))
                else:
                    db.execute("UPDATE vehicles SET plate_digits=?, plate_letters=? WHERE plate=?",
                               (dg, eff_lt, pl))

            db.execute("INSERT INTO schema_migrations VALUES(5, ?, 'Canonical letters-digits PK, persons internal ID, alert lease & repeat_count')", (time.time(),))

        if cur_ver < 6:
            cols_f = {r[1] for r in db.execute("PRAGMA table_info(faces)").fetchall()}
            for col, ddl in (
                ("person_id", "ALTER TABLE faces ADD COLUMN person_id INTEGER DEFAULT 0"),
                ("quarantined", "ALTER TABLE faces ADD COLUMN quarantined INTEGER DEFAULT 0"),
                ("quarantine_reason", "ALTER TABLE faces ADD COLUMN quarantine_reason TEXT DEFAULT ''"),
            ):
                if col not in cols_f:
                    try: db.execute(ddl)
                    except sqlite3.OperationalError: pass
            db.execute("CREATE INDEX IF NOT EXISTS idx_faces_person_id ON faces(person_id)")

            cols_a = {r[1] for r in db.execute("PRAGMA table_info(alerts)").fetchall()}
            if "dispatch_owner" not in cols_a:
                try: db.execute("ALTER TABLE alerts ADD COLUMN dispatch_owner TEXT DEFAULT ''")
                except sqlite3.OperationalError: pass

            db.executescript("""
            CREATE TABLE IF NOT EXISTS evidence_archive_ops(
              orig_rel TEXT PRIMARY KEY,
              arch_rel TEXT,
              sha256 TEXT,
              alert_id INTEGER DEFAULT 0,
              started_ts REAL,
              completed_ts REAL DEFAULT 0,
              who TEXT DEFAULT '',
              status TEXT DEFAULT 'in_progress'
            );
            """)
            migrate_legacy_faces(db)
            db.execute("INSERT INTO schema_migrations VALUES(6, ?, 'Strict person_id face isolation, quarantine legacy faces, dispatch_owner, archive ops journal')", (time.time(),))

        if not was_in_tx:
            db.commit()


def init(db, lock, log, refresh, db_path=None):
    D.update(db=db, lock=lock, log=log, refresh=refresh, db_path=db_path)
    migrate_db(db, lock, db_path=db_path)


def pick(v, kw, default):
    v = str(v or "").strip().lower()
    if not v: return default
    for code, ks in kw.items():
        if v == code or any(k in v for k in ks): return code
    return None


def cell(v):
    if v is None: return ""
    if isinstance(v, float) and v.is_integer(): return str(int(v))
    return str(v).strip()


def clean_vehicle(d):
    """Validate and canonicalize a vehicle record.
    P0-C: The canonical primary key is 'letters-digits' whenever plate letters or governorate exist."""
    raw_plate = d.get("plate")
    digits_only, letters_only = split_plate(raw_plate)
    if not (3 <= len(digits_only) <= 8):
        return None, "رقم اللوحة غير صالح (يجب أن يتضمن 3 إلى 8 أرقام)"
    st = pick(d.get("status"), KW_V, "normal")
    if st is None:
        return None, f"حالة غير معروفة: {d.get('status')}"
    g = lambda k, n=60: str(d.get(k) or "").strip()[:n]
    gov = g("governorate", 30)
    eff_letters = letters_only or _norm_letters_only(gov)
    canon_plate = f"{eff_letters}-{digits_only}" if eff_letters else digits_only
    if len(canon_plate) > 20:
        return None, "رقم اللوحة طويل جداً"
    return dict(
        plate=canon_plate, plate_digits=digits_only, plate_letters=eff_letters,
        governorate=gov, model=g("model"), color=g("color", 30),
        vtype=pick(d.get("vtype"), KW_T, "car") or "other",
        owner=g("owner"), status=st, notes=g("notes", 200)
    ), None


def clean_person(d):
    n = str(d.get("name") or "").strip()[:40]
    if not n: return None, "الاسم مطلوب"
    st = pick(d.get("status"), KW_P, "normal")
    if st is None: return None, f"حالة غير معروفة: {d.get('status')}"
    c = d.get("consent"); c = c is True or str(c).strip().lower() in ("1", "true", "yes", "y", "نعم", "موافق")
    g = lambda k, m: str(d.get(k) or "").strip()[:m]
    raw_id = d.get("id") if d.get("id") is not None else d.get("person_id")
    pid = int(raw_id) if str(raw_id or "").isdigit() and int(raw_id) > 0 else None
    return dict(id=pid, name=n, ref=g("ref", 30), category=g("category", 30) or "متطوع", status=st, consent=int(c), notes=g("notes", 200)), None


def _up_vehicle(c, allow_downgrade=True):
    db = D["db"]
    ex = db.execute("SELECT status FROM vehicles WHERE plate=?", (c["plate"],)).fetchone()
    if ex and not allow_downgrade and ex[0] in ("wanted", "stolen") and c["status"] not in ("wanted", "stolen"):
        return "protected_skip"
    db.execute("""INSERT INTO vehicles(plate,plate_digits,plate_letters,governorate,model,color,vtype,owner,status,notes,updated)
      VALUES(:plate,:plate_digits,:plate_letters,:governorate,:model,:color,:vtype,:owner,:status,:notes,:u)
      ON CONFLICT(plate) DO UPDATE SET plate_digits=:plate_digits, plate_letters=:plate_letters,
      governorate=:governorate, model=:model, color=:color, vtype=:vtype,
      owner=:owner, status=:status, notes=:notes, updated=:u""", {**c, "u": time.time()})
    return "updated" if ex else "added"


def _up_person(c):
    """Insert or update a person record and update/delete ONLY that person's face embeddings via person_id (P0-A)."""
    db = D["db"]
    migrate_legacy_faces(db)
    pid = c.get("id")
    ex = None
    if pid:
        row = db.execute("SELECT id, name, COALESCE(ref,'') FROM persons WHERE id=?", (pid,)).fetchone()
        if row:
            ex = row
    if not ex and c["ref"]:
        row = db.execute("SELECT id, name, COALESCE(ref,'') FROM persons WHERE name=? AND COALESCE(ref,'')=?", (c["name"], c["ref"])).fetchone()
        if row:
            ex = row
            pid = row[0]
    if not ex and not c["ref"]:
        ex_any = db.execute("SELECT id, name, COALESCE(ref,'') FROM persons WHERE name=?", (c["name"],)).fetchall()
        if len(ex_any) == 1:
            ex = ex_any[0]
            pid = ex[0]
            c = {**c, "ref": ex[2]}
        elif len(ex_any) > 1:
            raise ValueError("يوجد أكثر من شخص بنفس الاسم في السجل؛ يرجى تحديد الرقم المرجعي (ref) أو المعرّف (id) لمنع خلط الهويات")

    now_u = time.time()
    if ex and pid:
        db.execute(
            "UPDATE persons SET name=?, ref=?, category=?, status=?, consent=?, notes=?, updated=? WHERE id=?",
            (c["name"], c["ref"], c["category"], c["status"], c["consent"], c["notes"], now_u, pid)
        )
        action = "updated"
    else:
        cur = db.execute(
            "INSERT INTO persons(name,ref,category,status,consent,notes,updated) VALUES(?,?,?,?,?,?,?)",
            (c["name"], c["ref"], c["category"], c["status"], c["consent"], c["notes"], now_u)
        )
        pid = int(cur.lastrowid)
        action = "added"

    # P0-A: Strictly scope consent revocation and watchlist updates to person_id == pid ONLY!
    if not c["consent"]:
        db.execute("DELETE FROM faces WHERE person_id=?", (pid,))
    else:
        db.execute(
            "UPDATE faces SET watch=?, name=? WHERE person_id=? AND COALESCE(quarantined, 0)=0",
            (int(c["status"] == "watch"), c["name"], pid)
        )
    return action, pid


def save_vehicle(d, ip):
    c, e = clean_vehicle(d)
    if e: return {"ok": False, "error": e}
    allow_down = bool(d.get("force", True))
    with interprocess_db_lock():
        try:
            a = _up_vehicle(c, allow_downgrade=allow_down)
            D["db"].commit()
        except Exception as ex:
            D["db"].rollback(); return {"ok": False, "error": str(ex)}
    D["log"](f"registry vehicle {a}", f"{c['plate']} status={c['status']} by {ip}")
    return {"ok": True, "action": a, "plate": c["plate"]}


def save_person(d, ip):
    c, e = clean_person(d)
    if e: return {"ok": False, "error": e}
    with interprocess_db_lock():
        try:
            a, pid = _up_person(c); D["db"].commit()
        except Exception as ex:
            D["db"].rollback(); return {"ok": False, "error": str(ex)}
    p_tag = pseud(f"{pid}:{c['name']}")
    D["log"](f"registry person {a}", f"{p_tag} id={pid} ref={c['ref']} status={c['status']} consent={c['consent']} by {ip}")
    D["refresh"]()
    return {"ok": True, "action": a, "id": pid, "person_id": pid}


def delete(kind, key, ip):
    """Delete a vehicle or person record safely (P0-A item 5):
    - Deleting a person by id, ref, or unambiguous name deletes ONLY that person's face embeddings (person_id=pid),
      never wiping embeddings of homonymous persons."""
    db = D["db"]
    with interprocess_db_lock():
        try:
            if kind == "vehicles":
                ref = norm_plate(key)
                n = db.execute("DELETE FROM vehicles WHERE plate=? OR plate_digits=?", (ref, key)).rowcount
            else:
                migrate_legacy_faces(db)
                s_key = str(key or "").strip()
                target_pid = None
                if s_key.startswith("id:") and s_key[3:].isdigit():
                    target_pid = int(s_key[3:])
                elif s_key.isdigit():
                    row_by_id = db.execute("SELECT id FROM persons WHERE id=?", (int(s_key),)).fetchone()
                    if row_by_id:
                        target_pid = int(row_by_id[0])

                if target_pid is not None:
                    row = db.execute("SELECT id, name, COALESCE(ref,'') FROM persons WHERE id=?", (target_pid,)).fetchone()
                    if not row:
                        n = 0
                        ref = pseud(s_key)
                    else:
                        n = db.execute("DELETE FROM persons WHERE id=?", (target_pid,)).rowcount
                        # P0-A: Delete ONLY faces belonging to this exact person_id!
                        db.execute("DELETE FROM faces WHERE person_id=?", (target_pid,))
                        ref = f"{pseud(f'{target_pid}:{row[1]}')} id={target_pid}"
                else:
                    # Check if key matches a unique ref first, else check name
                    by_ref = db.execute("SELECT id, name, COALESCE(ref,'') FROM persons WHERE ref=? AND COALESCE(ref,'')!=''", (s_key,)).fetchall()
                    if len(by_ref) == 1:
                        target_pid, nm, _ = by_ref[0]
                        n = db.execute("DELETE FROM persons WHERE id=?", (target_pid,)).rowcount
                        db.execute("DELETE FROM faces WHERE person_id=?", (target_pid,))
                        ref = f"{pseud(f'{target_pid}:{nm}')} id={target_pid}"
                    else:
                        by_name = db.execute("SELECT id, name, COALESCE(ref,'') FROM persons WHERE name=?", (s_key,)).fetchall()
                        if len(by_name) > 1:
                            db.rollback()
                            return {
                                "ok": False,
                                "error": "يوجد أكثر من شخص بنفس الاسم؛ يجب الحذف باستخدام المعرّف الداخلي (id) أو الرقم المرجعي (ref) لمنع حذف سجلات شخص آخر"
                            }
                        elif len(by_name) == 1:
                            target_pid, nm, _ = by_name[0]
                            n = db.execute("DELETE FROM persons WHERE id=?", (target_pid,)).rowcount
                            db.execute("DELETE FROM faces WHERE person_id=?", (target_pid,))
                            ref = f"{pseud(f'{target_pid}:{nm}')} id={target_pid}"
                        else:
                            n = 0
                            ref = pseud(s_key)
            db.commit()
        except Exception:
            db.rollback(); raise
    if n:
        D["log"](f"registry {kind} deleted", f"{ref} by {ip}")
    if kind == "persons":
        D["refresh"]()
    return {"ok": bool(n)}


def list_rows(kind, q=""):
    q_s = q.strip()
    q_digits, _ = split_plate(q_s)
    like = f"%{q_s}%"
    like_d = f"%{q_digits}%" if q_digits else like
    db = D["db"]
    with D["lock"]:
        if kind == "vehicles":
            cur = db.execute("""SELECT plate, governorate, model, color, vtype, owner, status, notes FROM vehicles
              WHERE plate LIKE ? OR plate_digits LIKE ? OR model LIKE ? OR owner LIKE ? OR governorate LIKE ?
              ORDER BY updated DESC LIMIT 500""", (like, like_d, like, like, like))
        else:
            migrate_legacy_faces(db)
            cur = db.execute("""SELECT p.id, p.name, p.ref, p.category, p.status, p.consent, p.notes,
              (SELECT COUNT(*) FROM faces f WHERE f.person_id = p.id AND COALESCE(f.quarantined, 0) = 0) AS face_samples FROM persons p
              WHERE p.name LIKE ? OR p.ref LIKE ? OR p.category LIKE ? ORDER BY p.updated DESC LIMIT 500""", (like,) * 3)
        cols = [c[0] for c in cur.description]; rows = cur.fetchall()
    return [dict(zip(cols, r)) for r in rows]


def lookup_vehicle(plate):
    """Look up a vehicle using core digits + secondary letters/governorate (P0-A, P0-B, P0-C)."""
    q_digits, q_letters, ocr_fixed = split_plate_ex(plate)
    if not q_digits:
        return None
    with D["lock"]:
        cur = D["db"].execute(
            "SELECT plate, COALESCE(plate_digits,''), COALESCE(plate_letters,''), governorate, model, color, vtype, owner, status, notes "
            "FROM vehicles WHERE plate_digits=? OR plate=?",
            (q_digits, norm_plate(plate))
        )
        rows = cur.fetchall()
    if not rows:
        with D["lock"]:
            cur2 = D["db"].execute("SELECT plate, COALESCE(plate_digits,''), COALESCE(plate_letters,''), governorate, model, color, vtype, owner, status, notes FROM vehicles")
            all_v = cur2.fetchall()
        rows = [r for r in all_v if (r[1] or split_plate(r[0])[0]) == q_digits]

        if not rows:
            approx = []
            for r in all_v:
                r_st = r[8] or "normal"
                if r_st not in ("wanted", "stolen"):
                    continue
                r_dg = r[1] or split_plate(r[0])[0]
                if _edit_distance_1(q_digits, r_dg):
                    approx.append(r)
            if approx:
                pl, pdg, plt, gov, mod, col, vt, own, st, nt = approx[0]
                dg, lt_from_pl = split_plate(pl)
                eff_lt = plt or lt_from_pl or _norm_letters_only(gov)
                return {
                    "plate": pl, "plate_digits": dg, "plate_letters": eff_lt,
                    "governorate": gov or "", "model": mod or "", "color": col or "",
                    "vtype": vt or "car", "owner": own or "", "status": st or "normal", "notes": nt or "",
                    "match_type": "approximate",
                    "match_note": "تطابق تقريبي (مسافة تحرير 1) — تطابق محتمل يتطلب تحققاً بصرياً",
                    "conf_factor": 0.75,
                    "ambiguous": False,
                    "contradictory_letters": False,
                    "visual_check_only": True
                }
            return None

    candidates = []
    for pl, pdg, plt, gov, mod, col, vt, own, st, nt in rows:
        dg, lt_from_pl = split_plate(pl)
        eff_lt = plt or lt_from_pl or _norm_letters_only(gov)
        candidates.append({
            "plate": pl, "plate_digits": dg, "plate_letters": eff_lt,
            "governorate": gov or "", "model": mod or "", "color": col or "",
            "vtype": vt or "car", "owner": own or "", "status": st or "normal", "notes": nt or ""
        })

    if ocr_fixed:
        c = candidates[0]
        return {
            **c,
            "match_type": "approximate",
            "match_note": "تطابق تقريبي (تصحيح التباس محارف OCR مثل O/0 أو I/1) — تحقق بصري",
            "conf_factor": 0.80,
            "ambiguous": len(candidates) > 1,
            "contradictory_letters": False,
            "visual_check_only": True
        }

    if len(candidates) == 1:
        c = candidates[0]
        rec_lt = c["plate_letters"]
        if (not q_letters and not rec_lt) or (q_letters and rec_lt and q_letters == rec_lt):
            return {
                **c, "match_type": "exact", "match_note": "مطابقة كاملة",
                "conf_factor": 1.0, "ambiguous": False, "contradictory_letters": False, "visual_check_only": False
            }
        if not q_letters or not rec_lt:
            return {
                **c, "match_type": "digits_only",
                "match_note": "تطابق بالأرقام فقط، الأحرف غير مؤكدة",
                "conf_factor": 0.85, "ambiguous": False, "contradictory_letters": False, "visual_check_only": False
            }
        sim = _letter_similarity(q_letters, rec_lt)
        if sim >= 0.5:
            return {
                **c, "match_type": "digits_only",
                "match_note": "تطابق بالأرقام فقط، الأحرف غير مؤكدة (تشابه جزئي للأحرف)",
                "conf_factor": 0.85, "ambiguous": False, "contradictory_letters": False, "visual_check_only": False
            }
        return {
            **c, "match_type": "digits_only",
            "match_note": f"تطابق محتمل — تحقق بصري (تطابق بالأرقام فقط مع تعارض الأحرف/المحافظة: المقروء «{q_letters}» مقابل المسجل «{rec_lt}»)",
            "conf_factor": 0.60, "ambiguous": False, "contradictory_letters": True, "visual_check_only": True
        }

    if q_letters:
        scored = sorted(
            ((_letter_similarity(q_letters, c["plate_letters"]), c) for c in candidates),
            key=lambda x: x[0],
            reverse=True
        )
        best_sim, best_c = scored[0]
        second_sim = scored[1][0] if len(scored) > 1 else 0.0
        if best_sim == 1.0 and best_sim > second_sim:
            return {
                **best_c, "match_type": "exact", "match_note": "مطابقة كاملة (أرقام + أحرف)",
                "conf_factor": 1.0, "ambiguous": False, "contradictory_letters": False, "visual_check_only": False
            }
        if best_sim >= 0.5 and best_sim > second_sim:
            return {
                **best_c, "match_type": "digits_only",
                "match_note": "تطابق بالأرقام فقط، الأحرف غير مؤكدة (تم اختيار الأقرب بالأحرف)",
                "conf_factor": 0.85, "ambiguous": False, "contradictory_letters": False, "visual_check_only": False
            }

    prio = {"wanted": 5, "stolen": 4, "watch": 3, "expired": 2, "normal": 1}
    candidates.sort(key=lambda c: -prio.get(c["status"], 0))
    chosen = dict(candidates[0])
    all_plates = " / ".join(c["plate"] for c in candidates)
    chosen.update(
        match_type="ambiguous",
        ambiguous=True,
        contradictory_letters=bool(q_letters),
        visual_check_only=True,
        candidates=[c["plate"] for c in candidates],
        match_note=f"تطابق محتمل — تحقق بصري (تطابق بالأرقام فقط مع تعدد سجلات بنفس الأرقام: {all_plates})",
        conf_factor=0.65
    )
    return chosen


def get_person(name="", ref="", person_id=None):
    """Resolve a person record unambiguously by internal person_id, (name, ref), or unique name (P0-A).
    Returns None if multiple records share the given name and neither person_id nor ref was provided."""
    s_name = str(name or "").strip()
    if person_id is None and s_name.startswith("id:") and s_name[3:].isdigit():
        person_id = int(s_name[3:])
        s_name = ""
    if person_id is not None and str(person_id).isdigit():
        pid = int(person_id)
        with D["lock"]:
            r = D["db"].execute(
                "SELECT id, name, COALESCE(ref,''), category, status, consent, notes FROM persons WHERE id=?",
                (pid,)
            ).fetchone()
        if r:
            return dict(zip(("id", "name", "ref", "category", "status", "consent", "notes"), r))
        return None
    s_ref = str(ref or "").strip()
    rows = list_rows("persons", s_name or s_ref)
    if s_ref:
        matches = [x for x in rows if (not s_name or x["name"] == s_name) and x.get("ref") == s_ref]
        if len(matches) == 1:
            return matches[0]
        return None
    if s_name:
        matches = [x for x in rows if x["name"] == s_name]
        if len(matches) == 1:
            return matches[0]
    return None


def parse_file(fn, data):
    f = fn.lower()
    if f.endswith((".xlsx", ".xlsm")):
        try: from openpyxl import load_workbook
        except ImportError: raise ValueError("لقراءة Excel ثبّت: pip install openpyxl (أو احفظ الملف بصيغة CSV)")
        ws = load_workbook(io.BytesIO(data), read_only=True, data_only=True).active
        return [[cell(c) for c in r] for r in ws.iter_rows(values_only=True)]
    if f.endswith((".csv", ".txt")):
        try: txt = data.decode("utf-8-sig")
        except UnicodeDecodeError: txt = data.decode("cp1256", "replace")
        try: dia = csv.Sniffer().sniff(txt[:2000], delimiters=",;\t")
        except csv.Error: dia = csv.excel
        return [[cell(c) for c in r] for r in csv.reader(io.StringIO(txt), dia)]
    raise ValueError("صيغة غير مدعومة: استخدم ملف .xlsx أو .csv")


def import_file(kind, filename, data, ip, force_overwrite=False):
    veh = kind == "vehicles"
    try: rows = [r for r in parse_file(filename, data) if any(r)]
    except Exception as e: return {"ok": False, "error": str(e)}
    if not rows: return {"ok": False, "error": "الملف فارغ"}
    alias, clean, need = (AV, clean_vehicle, "plate") if veh else (AP, clean_person, "name")
    hdr = [alias.get(hkey(h)) for h in rows[0]]
    if need not in hdr:
        return {"ok": False, "error": "لم أجد عمود " + ("رقم اللوحة" if veh else "الاسم") + " في السطر الأول. حمّل القالب واستخدم عناوينه."}
    add = upd = 0; errs = []; warnings = []
    seen_in_file = {}
    with interprocess_db_lock():
        try:
            for i, r in enumerate(rows[1:], start=2):
                d = {k: r[j] for j, k in enumerate(hdr) if k and j < len(r)}
                if (veh and split_plate(d.get("plate"))[0] == "00000") or (not veh and str(d.get("name", "")).startswith("مثال")):
                    continue
                c, e = clean(d)
                if e:
                    errs.append(f"السطر {i}: {e}"); continue
                rec_key = c["plate"] if veh else f"{c['name']}|{c.get('ref','')}"
                if rec_key in seen_in_file:
                    warnings.append(f"السطر {i}: تكرار المفتاح «{rec_key}» داخل نفس الملف (سبقه السطر {seen_in_file[rec_key]})")
                seen_in_file[rec_key] = i
                if veh:
                    a = _up_vehicle(c, allow_downgrade=force_overwrite)
                    if a == "protected_skip":
                        warnings.append(f"السطر {i}: لم يُستبدل السجل الأمني الحرج للوحة «{c['plate']}» بحالة أقل دون تأكيد صريح")
                        continue
                else:
                    try:
                        a, _ = _up_person(c)
                    except ValueError as ve:
                        errs.append(f"السطر {i}: {ve}"); continue
                add += a == "added"; upd += a == "updated"
            D["db"].commit()
        except Exception as ex:
            D["db"].rollback()
            return {"ok": False, "error": f"فشل حفظ البيانات: {ex}"}
    D["log"](f"registry import {kind}", f"+{add} ~{upd} !{len(errs)} w={len(warnings)} sha256={hashlib.sha256(data).hexdigest()[:16]} by {ip}")
    if not veh:
        D["refresh"]()
    return {"ok": True, "added": add, "updated": upd, "skipped": len(errs), "errors": errs[:10], "warnings": warnings[:10]}


def template(kind):
    heads, ex = (VH, VEX) if kind == "vehicles" else (PH, PEX)
    try:
        from openpyxl import Workbook
        wb = Workbook(); ws = wb.active; ws.sheet_view.rightToLeft = True
        ws.append(heads); ws.append(ex); buf = io.BytesIO(); wb.save(buf)
        return buf.getvalue(), f"mersad_{kind}_template.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    except ImportError:
        s = io.StringIO(); w = csv.writer(s); w.writerow(heads); w.writerow(ex)
        return s.getvalue().encode("utf-8-sig"), f"mersad_{kind}_template.csv", "text/csv; charset=utf-8"
