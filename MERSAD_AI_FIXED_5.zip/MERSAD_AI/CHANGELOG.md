# سجل التغييرات — MERSAD AI (الجولات 1 إلى 5 — `MERSAD_AI_FIXED_5.zip`)

يُوثّق هذا الملف سجل التغييرات الكامل عبر الجولات الخمس، مع تفصيل دقيق لتعديلات الجولة الخامسة النهائية (`MERSAD_AI_FIXED_4.zip` ➔ `MERSAD_AI_FIXED_5.zip`).

---

## أولاً: ملخص الملفات المعدّلة أو المضافة في الجولة الخامسة (`MERSAD_AI_FIXED_5.zip`)

| الملف | الإجراء | سبب التعديل في الجولة الخامسة |
|---|---|---|
| `requirements.txt` | مُعدّل | توحيد إصدارات مكتبات وقت التشغيل (`opencv-python==4.11.0.86`, `numpy==1.26.4`, `Pillow==10.4.0`, `easyocr==1.7.2`, `ultralytics==8.3.0`, `openpyxl==3.1.5`, `scikit-learn==1.5.2`) وإزالة أي تضارب مع التقارير وسكربتات التثبيت. |
| `constraints-win-x64.txt` | جديد | ملف قفل/قيود شامل لبيئة Windows x64 (`Python 3.11 64-bit`) يثبّت إصدارات `torch==2.5.1` و `torchvision==0.20.1` و `pyinstaller==6.11.1` وجميع مكتبات وقت التشغيل لضمان إعادة إنتاج البناء بدقة. |
| `setup.bat` | مُعدّل | إلغاء التجاوز الأعمى لـ `venv\.ready`؛ استدعاء `check_install.py --verify-ready` للتحقق من بصمة الاعتماديات وإصدار Python والنماذج؛ تثبيت إصدارات `torch==2.5.1` و `torchvision==0.20.1` صراحةً؛ إزالة `opencv-python-headless` وتثبيت `opencv-python==4.11.0.86`؛ تشغيل `pip check`؛ وإنشاء `venv\.ready` ذرياً عبر `check_install.py --write-ready` بعد نجاح جميع الخطوات فقط. |
| `BUILD_EXE.bat` | مُعدّل | تثبيت إصدار `pyinstaller==6.11.1` صراحةً؛ تشغيل `check_install.py --strict` و `selftest.py` و `pip check` مع إيقاف البناء فوراً عند أي خطأ؛ حفظ سجل البناء في `build_pyinstaller.log`؛ توليد سكربتات تشغيل التوزيع (`dist\MERSAD_AI\RUN.bat`, `RUN_LAN.bat`, `VERIFY_AUDIT.bat`)؛ والتحقق من وجود `dist\MERSAD_AI\MERSAD_AI.exe` وجميع النماذج قبل إعلان النجاح. |
| `mersad_ai.spec` | جديد | ملف مواصفات PyInstaller معياري لبناء حزمة `--onedir` (`COLLECT`) مع استبعاد `opencv-python-headless` وتضمين كافة الوحدات المحلية والواجهة. |
| `.github/workflows/windows-build.yml` | جديد | سير عمل GitHub Actions آلي لبيئة `windows-latest` (`Python 3.11 x64`) ينفّذ تثبيت البيئة النظيفة، وفحص `pip check`، وتشغيل الاختبارات، وتنزيل النماذج والتحقق منها، وبناء `MERSAD_AI.exe`، واختبار تشغيله من مسارات تحتوي على مسافات وأحرف عربية بدون `venv`. |
| `prefetch.py` | مُعدّل | استخدام محرك التنزيل الآمن `safe_download_model` بملفات `.part` مؤقتة، ومهلة زمنية للمقبس (`timeout=30s`)، وإعادة محاولة محدودة، والتحقق من حجم الملف وبصمة `SHA-256` وبنية أرشيف `PyTorch ZIP` لنموذج `yolov8n.pt` (من إصدار `v8.3.0` الثابت) وأوزان `EasyOCR`، مع عدم حذف أو استبدال أي نموذج سليم قائم عند فشل التنزيل. |
| `check_install.py` | مُعدّل | ترقية شاملة لتصنيف الفحوصات إلى (`CORE_LOGIC`, `PYTHON_ENV`, `REQUIRED_LIB`, `OPTIONAL_LIB`, `VERSION_MISMATCH`, `VERSION_CONFLICT`, `BUILD_REQ`, `MODEL_MISSING`, `MODEL_CORRUPT`, `MODEL_OK`)، وإدارة بصمة `venv/.ready` (`--verify-ready`, `--write-ready`, `--strict`, `--json`). |
| `mersad_live.py` | مُعدّل | فصل صارم بين مسار الموارد القابلة للقراءة فقط (`BUNDLE_DIR` / `INSTALL_DIR`) ومجلد بيانات المستخدم القابل للكتابة (`APPDIR` عبر `resolve_writable_appdir` الذي يسقط تلقائياً إلى `%LOCALAPPDATA%\MERSAD_AI` إذا كان مجلد تثبيت `EXE` غير قابل للكتابة)، وإضافة دوال `verify_onnx_file` و `verify_yolo_pt_file` و `verify_easyocr_dir` و `safe_download_model`. |
| `RUN.bat` | مُعدّل | استخدام `check_install.py --strict` لمنع بدء التشغيل الحي إذا كانت إحدى المكتبات الأساسية أو النماذج مفقودة أو تالفة. |
| `selftest.py` | مُعدّل | الاحتفاظ بجميع الـ 109 اختبارات من الجولات 1–4، وإضافة 5 مجموعات اختبار سلوكية شاملة للجولة الخامسة (`R5-DEPS`, `R5-ENV`, `R5-MODELS`, `R5-PATHS`, `R5-DIAG`) ليصبح المجموع **114 اختباراً ناجحاً (`114 PASS, 0 SKIP, 0 FAIL`)**. |
| `AUDIT_REPORT.md`, `TEST_REPORT.md`, `BUILD_REPORT.md`, `README_AR.md` | مُعدّل | مطابقة جميع أرقام الإصدارات وخطوات البناء ونتائج الاختبارات مع الكود الفعلي بنسبة 100%. |
